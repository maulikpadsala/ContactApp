package com.example.contactapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class AddNewContact extends Fragment {

    //Binding AddNewContact fragment All View
    private TextInputEditText editText_name,editText_number;
    private TextInputLayout textInputLayoutName,textInputLayoutNumber;
    private Button button_save;

    private final DatabaseHelper myDB = new DatabaseHelper(getActivity());


    public AddNewContact()
    {

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_addnewcontact, container, false);
        editText_name = view.findViewById(R.id.editText_name);
        editText_number = view.findViewById(R.id.editText_number);
        textInputLayoutName = view.findViewById(R.id.textInputLayoutName);
        textInputLayoutNumber = view.findViewById(R.id.textInputLayoutNumber);
        button_save = view.findViewById(R.id.button_save);
        return view;
    }
    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        button_save.setOnClickListener(view1 -> {
            String name = editText_name.getText().toString();
            String number = editText_number.getText().toString();
            if (name != null && number != null){
                if (myDB.insertData(name,number)){
                    editText_name.setText("");
                    editText_number.setText("");
                    Toast.makeText(getContext(), "Inserted Successfull", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "wrong", Toast.LENGTH_SHORT).show();
                }
            }

        });

    }
}