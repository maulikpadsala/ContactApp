package com.example.contactapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdaptorContactList extends RecyclerView.Adapter<AdaptorContactList.HomeViewHolder> {

    public class HomeViewHolder extends RecyclerView.ViewHolder{

        LinearLayout recyclerClickContact;
        TextView character,contactName;


        public HomeViewHolder(@NonNull View i) {
            super(i);

            character = i.findViewById(R.id.character);
            contactName = i.findViewById(R.id.contactName);
            recyclerClickContact = i.findViewById(R.id.recyclerClickContact);
        }
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_contact_list, parent, false);
        HomeViewHolder homeViewHolder = new HomeViewHolder(view);
        return homeViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {
        holder.recyclerClickContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                
            }
        });
    }

    @Override
    public int getItemCount() {
        return 5;    }



}

